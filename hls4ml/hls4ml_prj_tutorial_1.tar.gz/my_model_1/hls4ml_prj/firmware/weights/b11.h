//Numpy array shape [1]
//Min 0.035765044391
//Max 0.035765044391
//Number of zeros 0

#ifndef B11_H_
#define B11_H_

#ifndef __SYNTHESIS__
model_default_t b11[1];
#else
model_default_t b11[1] = {0.0357650444};
#endif

#endif
