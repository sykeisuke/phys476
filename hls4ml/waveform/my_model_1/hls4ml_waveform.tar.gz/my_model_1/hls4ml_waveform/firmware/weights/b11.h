//Numpy array shape [4]
//Min 0.010885685682
//Max 0.081158198416
//Number of zeros 0

#ifndef B11_H_
#define B11_H_

#ifndef __SYNTHESIS__
model_default_t b11[4];
#else
model_default_t b11[4] = {0.0811581984, 0.0290957782, 0.0603363328, 0.0108856857};
#endif

#endif
